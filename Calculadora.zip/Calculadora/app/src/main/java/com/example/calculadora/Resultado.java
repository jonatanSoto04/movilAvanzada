package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Stack;

public class Resultado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        TextView pantalla = findViewById(R.id.pantalla);

        Button sum = findViewById(R.id.sum);
        Button multi = findViewById(R.id.multi);
        Button divi = findViewById(R.id.divi);
        Button res = findViewById(R.id.res);
        Button n1 = findViewById(R.id.n1);
        Button n2 = findViewById(R.id.n2);
        Button n3 = findViewById(R.id.n3);
        Button n4 = findViewById(R.id.n4);
        Button n5 = findViewById(R.id.n5);
        Button n6 = findViewById(R.id.n6);
        Button n7 = findViewById(R.id.n7);
        Button n8 = findViewById(R.id.n8);
        Button n9 = findViewById(R.id.n9);
        Button n0 = findViewById(R.id.n0);
        Button resultado = findViewById(R.id.resultado);
        Button fibo = findViewById(R.id.fibo);
        Button facto = findViewById(R.id.factor);

        fibo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fibon = new Intent(Resultado.this, MainActivity.class);
                startActivity(fibon);
            }
        });

        facto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent facto = new Intent(Resultado.this, calculadora.class);
                startActivity(facto);
            }
        });




        sum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = sum.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = res.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = multi.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        divi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = divi.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n1.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n2.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n3.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n4.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n5.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n6.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n7.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n8.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });


        n8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n8.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n9.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        n0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String button = n0.getText().toString();
                String currentText = pantalla.getText().toString();
                pantalla.setText(currentText + button);
            }
        });

        resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = pantalla.getText().toString(); // Obtén el texto de la pantalla
                String[] values = input.split("[+\\-*/]"); // Separa los valores basados en operadores matemáticos

                if (values.length == 2) { // Verifica que se ingresó una operación válida
                    double num1 = Double.parseDouble(values[0]);
                    double num2 = Double.parseDouble(values[1]);
                    char operator = input.charAt(values[0].length()); // Captura el operador

                    double result = 0;
                    switch (operator) {
                        case '+':
                            result = num1 + num2;
                            break;
                        case '-':
                            result = num1 - num2;
                            break;
                        case '*':
                            result = num1 * num2;
                            break;
                        case '/':
                            if (num2 != 0) {
                                result = num1 / num2;
                            } else {
                                pantalla.setText("Error: División entre cero"); // Manejo de división entre cero
                                return;
                            }
                            break;
                        default:
                            pantalla.setText("Error: Operador inválido");
                            return;
                    }
                    pantalla.setText(String.valueOf(result)); // Muestra el resultado en el TextView
                } else {
                    pantalla.setText("Error: Entrada inválida");
                }
            }
        });

    }
}